document.addEventListener('DOMContentLoaded', function () {
  const checkButton = document.getElementById('checkButton');
  const websiteUrlInput = document.getElementById('websiteUrl');
  const resultDiv = document.getElementById('result');

  checkButton.addEventListener('click', function () {
    const websiteUrl = websiteUrlInput.value;
    console.log(`Checking robots.txt for: ${websiteUrl}`);

    chrome.runtime.sendMessage({ action: 'checkRobotsTxt', websiteUrl }, function (response) {
      if (chrome.runtime.lastError) {
        console.error('Error: ' + chrome.runtime.lastError);
        resultDiv.innerText = 'Error: ' + chrome.runtime.lastError;
      } else if (response.error) {
        console.error('Error: ' + response.error);
        resultDiv.innerText = 'Error: ' + response.error;
      } else {
        console.log('User Agents:', response.userAgents);
        console.log('Allow Rules:', response.allowRules);
        console.log('Disallow Rules:', response.disallowRules);

        const allowRulesText = response.allowRules.length > 0 ? response.allowRules.join('\n') : 'No Allow Rules';
        const disallowRulesText = response.disallowRules.length > 0 ? response.disallowRules.join('\n') : 'No Disallow Rules';

        resultDiv.innerHTML = `
          <strong>User Agents:</strong><br>${response.userAgents.join('<br>')}<br><br>
          <strong>Allow Rules:</strong><br><pre>${allowRulesText}</pre><br>
          <strong>Disallow Rules:</strong><br><pre>${disallowRulesText}</pre>
        `;
      }
    });
  });
});
