chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "checkRobotsTxt") {
    const websiteUrl = request.websiteUrl;
    console.log(`Fetching robots.txt for: ${websiteUrl}`);

    // Construct the URL for the robots.txt file
    const robotsTxtUrl = websiteUrl + "/robots.txt";

    // Fetch the robots.txt file
    fetch(robotsTxtUrl)
      .then((response) => response.text())
      .then((robotsTxtContent) => {
        console.log('Robots.txt Content:', robotsTxtContent);

        // Parse the robots.txt content to check for user-agents and allow/disallow rules
        const lines = robotsTxtContent.split("\n");
        const userAgents = [];
        const allowRules = [];
        const disallowRules = [];
        let currentUserAgent = null;

        for (const line of lines) {
          if (line.toLowerCase().startsWith("user-agent:")) {
            currentUserAgent = line.substring(12).trim();
          } else if (line.toLowerCase().startsWith("allow:")) {
            if (currentUserAgent) {
              allowRules.push(line.substring(7).trim());
            }
          } else if (line.toLowerCase().startsWith("disallow:")) {
            if (currentUserAgent) {
              disallowRules.push(line.substring(10).trim());
            }
          }
        }

        const result = {
          userAgents,
          allowRules,
          disallowRules,
        };

        console.log('User Agents:', userAgents);
        console.log('Allow Rules:', allowRules);
        console.log('Disallow Rules:', disallowRules);

        sendResponse(result);
      })
      .catch((error) => {
        console.error('Error:', error.message);
        sendResponse({ error: error.message });
      });

    return true; // Required to indicate that the response will be sent asynchronously
  }
});
